import { Link } from "react-router-dom";
import Relation from "../../pages/relation/Relation";
import "./header.css";
export default function Header() {
  return (
    <>
      <header>
      
        <div className="right">
          <Link to="/">
            <button className="btn">Add People </button>
          </Link>

          <Link to="/connect">
            <button className="btn">Set Relation</button>
          </Link>

          <Link to="/view">
            <button className="btn">Discover Connection </button>
          </Link>
          
        </div>
      </header>
    </>
  );
}
